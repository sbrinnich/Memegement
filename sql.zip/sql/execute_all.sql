-- Run this script with: SQLCMD -S Servername\Instancename -d DatabaseName -i execute_all.sql

--This Script does not work, chill...

:r create_db.sql
:r insert_testdata.sql