Use Memegement;
GO

SELECT * FROM Gruppe;

INSERT INTO Gruppe (name, beschreibung, gruendungsDatum, gruenderId, gruppenBild) VALUES
  ('Testy', '', '2017-12-12', 1,1);
